#include "kinematics_control_node.hpp"

using MotorState = custom_interfaces::msg::MotorState;
using MotorCommand = custom_interfaces::msg::MotorCommand;
using namespace std::chrono_literals;

KinematicsControlNode::KinematicsControlNode()
{
  /**
   * @brief if use custom surgical tool, initialize.
   */
  // STLeft_.init_surgicaltool(1,1,1,1);
  // STRight_.init_surgicaltool(1,1,1,1);
}

KinematicsControlNode::~KinematicsControlNode() {

}


/**
 * @author DY
 * @brief E, W, S, N direction check (+1) or (-1)
 * @note  In xbox's left axes -> E:-, W:+, S:-, N:+
 *        In our definition   -> E:-, W:+, S:+, N:-
 *        mapping joystick data to angle of hardware limitation
 */
float KinematicsControlNode::mapping_joystick_to_bending_p() {
  float axes = this->joystick_msg_.axes[0];
  return (this->ST_.max_bending_deg_ * axes);
}
float KinematicsControlNode::mapping_joystick_to_bending_t() {
  float axes = this->joystick_msg_.axes[1];
  return ( -1 * this->ST_.max_bending_deg_ * axes);
}
float KinematicsControlNode::mapping_joystick_to_forceps() {
  float axes = this->joystick_msg_.axes[2];
  if ( axes >= 0) return ( this->ST_.max_forceps_deg_ * axes);
  else return 0;
}

void KinematicsControlNode::cal_kinematics() {
  /* code */
  /* output : target value*/

  /* mapping function */
  /*
  float pAngle = this->mapping_joystick_to_bending_p();
  float tAngle = this->mapping_joystick_to_bending_t();
  float gAngle  = this->mapping_joystick_to_forceps();
  */
  float pAngle = 0;
  float tAngle = 0;
  float gAngle = 0;

  this->ST_.get_bending_kinematic_result(pAngle, tAngle, gAngle);

  float f_val[NUM_OF_MOTORS];
  f_val[0] = this->ST_.wrLengthEast_;
  f_val[1] = this->ST_.wrLengthWest_;
  f_val[2] = this->ST_.wrLengthSouth_;
  f_val[3] = this->ST_.wrLengthNorth_;
  f_val[4] = this->ST_.wrLengthGrip;

  std::cout << "--------------------------" << std::endl;
  std::cout << "East  : " << f_val[0] << std::endl;
  std::cout << "West  : " << f_val[1] << std::endl;
  std::cout << "South : " << f_val[2] << std::endl;
  std::cout << "North : " << f_val[3] << std::endl;
  std::cout << "Grip  : " << f_val[4] << std::endl;

  // ratio conversion
  this->kinematics_control_target_pos_[0] = f_val[0] * gear_encoder_ratio_conversion(GEAR_RATIO_44, ENCODER_CHANNEL, ENCODER_RESOLUTION);
  this->kinematics_control_target_pos_[1] = f_val[1] * gear_encoder_ratio_conversion(GEAR_RATIO_44, ENCODER_CHANNEL, ENCODER_RESOLUTION);
  this->kinematics_control_target_pos_[2] = f_val[2] * gear_encoder_ratio_conversion(GEAR_RATIO_44, ENCODER_CHANNEL, ENCODER_RESOLUTION);
  this->kinematics_control_target_pos_[3] = f_val[3] * gear_encoder_ratio_conversion(GEAR_RATIO_44, ENCODER_CHANNEL, ENCODER_RESOLUTION);
  this->kinematics_control_target_pos_[4] = f_val[4] * gear_encoder_ratio_conversion(GEAR_RATIO_3_9, ENCODER_CHANNEL, ENCODER_RESOLUTION);

#if MOTOR_CONTROL_SAME_DURATION
  /**
   * @brief find max value and make it max_velocity_profile 100 (%),
   *        other value have values proportional to 100 (%) each
   */
  static double prev_f_val[DOF];  // for delta length

  std::vector<double> abs_f_val(DOF-1, 0);  // 5th DOF is a forceps
  // for (int i=0; i<DOF-1; i++) { abs_f_val[i] = std::abs(prev_f_val[i] - f_val[i]); }
  for (int i=0; i<DOF-1; i++) { abs_f_val[i] = std::abs(this->kinematics_control_target_pos_[i] - this->actual_pos); }
  std::cout << "--------------" << std::endl;
  std::cout << "Δ East  : " << abs_f_val[0] << " mm"<< std::endl;
  std::cout << "Δ West  : " << abs_f_val[1] << " mm"<< std::endl;
  std::cout << "Δ South : " << abs_f_val[2] << " mm"<< std::endl;
  std::cout << "Δ North : " << abs_f_val[3] << " mm"<< std::endl;
  std::cout << "Δ Grip  : " << abs_f_val[4] << " mm"<< std::endl;

  double max_val = *std::max_element(abs_f_val.begin(), abs_f_val.end()) + 0.00001; // 0.00001 is protection for 0/0 overflow (0 divided by 0)
  int max_val_index = std::max_element(abs_f_val.begin(), abs_f_val.end()) - abs_f_val.begin();
  for (int i=0; i<(DOF-1); i++) { 
    this->kinematics_control_target_velocity_profile_[i] = (abs_f_val[i] / max_val) * PERCENT_100;
  }
  // last index means forceps. It doesn't need velocity profile
  this->kinematics_control_target_velocity_profile_[DOF-1] = PERCENT_100;
  
#else
  for (int i=0; i<DOF; i++) { 
    this->kinematics_control_target_velocity_profile_[i] = PERCENT_100;
  }
#endif
}

float KinematicsControlNode::gear_encoder_ratio_conversion(float gear_ratio, int e_channel, int e_resolution) {
  return gear_ratio * e_channel * e_resolution;
}

void KinematicsControlNode::publishall()
{

}




